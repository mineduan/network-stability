function dx=funX(t,x,A,r,s)
dx=x.*(r+A*x);